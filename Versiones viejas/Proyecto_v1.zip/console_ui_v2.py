from trainer import EmotionTrainer
from predictor import EmotionPredictor
import cv2
import os


def print_preprocessing_options(trainer):
    print("\nMétodos de preprocesamiento disponibles:")
    for i, method in enumerate(trainer.preprocessing_methods.keys(), 1):
        print(f"{i}. {method}")
    print(f"{len(trainer.preprocessing_methods) + 1}. Volver")


def main():
    print("Sistema de Reconocimiento de Emociones")

    while True:
        print("\nMenú Principal:")
        print("1. Entrenar modelo")
        print("2. Predecir emoción")
        print("3. Salir")

        choice = input("Seleccione una opción: ")

        if choice == "1":
            data_path = input("Ruta del dataset (presione Enter para usar 'archive'): ") or "archive"
            trainer = EmotionTrainer(data_path)

            # Mostrar opciones de preprocesamiento
            while True:
                print_preprocessing_options(trainer)
                prep_choice = input("Seleccione método de preprocesamiento: ")

                if prep_choice == str(len(trainer.preprocessing_methods) + 1):
                    break

                try:
                    prep_index = int(prep_choice) - 1
                    if 0 <= prep_index < len(trainer.preprocessing_methods):
                        method = list(trainer.preprocessing_methods.keys())[prep_index]
                        trainer.train(preprocessing=method,model_name="emotion_classifier.joblib")

                        model_info = trainer.get_model_info()
                        print("\nInformación del Modelo:")
                        print(f"Emociones: {', '.join(model_info['emotions'])}")
                        print(f"Precisión: {model_info['accuracy']:.2f}")
                        print(f"Preprocesamiento usado: {method}")
                        print("Probabilidades a priori:")
                        for emotion, prob in model_info['prior_probabilities'].items():
                            print(f"  {emotion}: {prob:.2f}")
                        break
                    else:
                        print("Opción no válida")
                except ValueError:
                    print("Por favor ingrese un número válido")

        elif choice == "2":
            model_path = input(
                "Ruta del modelo (presione Enter para usar 'model/emotion_classifier.joblib'): ") or "model/emotion_classifier.joblib"

            try:
                predictor = EmotionPredictor(model_path)
                model_info = predictor.get_model_info()

                print(f"\nModelo cargado con preprocesamiento: {model_info['preprocessing_method']}")
                print(f"Precisión del modelo: {model_info['accuracy']:.2f}")

                print("\nOpciones de predicción:")
                print("1. Usar imagen de archivo")
                print("2. Usar cámara web")
                print("3. Probar diferentes preprocesamientos")
                pred_choice = input("Seleccione una opción: ")

                if pred_choice == "1":
                    image_path = input("Ingrese la ruta de la imagen: ")
                    if not os.path.exists(image_path):
                        print("Error: La imagen no existe")
                        continue

                    # Preguntar si quiere usar un preprocesamiento diferente
                    use_custom_prep = input("¿Usar un preprocesamiento diferente al del modelo? (s/n): ").lower() == 's'
                    prep_method = None

                    if use_custom_prep:
                        print("\nMétodos de preprocesamiento disponibles:")
                        methods = list(predictor._get_preprocessor('normalize').__self__.preprocessing_methods.keys())
                        for i, m in enumerate(methods, 1):
                            print(f"{i}. {m}")
                        prep_choice = input("Seleccione método: ")
                        try:
                            prep_index = int(prep_choice) - 1
                            if 0 <= prep_index < len(methods):
                                prep_method = methods[prep_index]
                        except:
                            print("Usando preprocesamiento por defecto del modelo")

                    result = predictor.predict_emotion(image_path, preprocessing=prep_method)
                    print("\nResultado de la predicción:")
                    print(f"Emoción: {result['emotion']}")
                    print(f"Confianza: {result['confidence']:.2f}")
                    print(f"Preprocesamiento usado: {result['preprocessing_used']}")
                    print("Probabilidades completas:")
                    for emotion, prob in result['probabilities'].items():
                        print(f"  {emotion}: {prob:.2f}")

                elif pred_choice == "2":
                    print("Presione 'q' para salir de la cámara")
                    cap = cv2.VideoCapture(0)

                    while True:
                        ret, frame = cap.read()
                        if not ret:
                            break

                        # Convertir a escala de grises para mostrar
                        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                        # Hacer predicción
                        result = predictor.predict_emotion(gray)

                        # Mostrar resultado en la imagen
                        cv2.putText(frame, f"Emotion: {result['emotion']}", (10, 30),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                        cv2.putText(frame, f"Confidence: {result['confidence']:.2f}", (10, 70),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                        cv2.putText(frame, f"Prep: {result['preprocessing_used']}", (10, 110),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                        cv2.imshow('Emotion Recognition', frame)

                        if cv2.waitKey(1) & 0xFF == ord('q'):
                            break

                    cap.release()
                    cv2.destroyAllWindows()

                elif pred_choice == "3":
                    image_path = input("Ingrese la ruta de la imagen: ")
                    if not os.path.exists(image_path):
                        print("Error: La imagen no existe")
                        continue

                    # Probar todos los métodos de preprocesamiento
                    methods = list(predictor._get_preprocessor('normalize').__self__.preprocessing_methods.keys())

                    for method in methods:
                        result = predictor.predict_emotion(image_path, preprocessing=method)
                        print(f"\nResultado con preprocesamiento '{method}':")
                        print(f"Emoción: {result['emotion']}")
                        print(f"Confianza: {result['confidence']:.2f}")
                        print("Probabilidades:")
                        for emotion, prob in result['probabilities'].items():
                            print(f"  {emotion}: {prob:.2f}")

            except FileNotFoundError:
                print("Error: No se encontró el modelo especificado")

        elif choice == "3":
            print("Saliendo...")
            break
        else:
            print("Opción no válida")


if __name__ == "__main__":
    main()