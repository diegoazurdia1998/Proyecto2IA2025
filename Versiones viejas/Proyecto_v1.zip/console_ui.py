from trainer import EmotionTrainer
from predictor import EmotionPredictor
import cv2
import os


def print_model_info(info):
    """Muestra información detallada del modelo"""
    print("\nInformación del Modelo:")
    print(f"Emociones: {', '.join(info['emotions'])}")
    print(f"Precisión: {info['accuracy']:.2f}")
    print(f"Preprocesamiento usado: {info['preprocessing_method']}")
    print("\nProbabilidades a priori:")
    for emotion, prob in info['prior_probabilities'].items():
        print(f"  {emotion}: {prob:.2f}")


def main():
    print("Sistema de Reconocimiento de Emociones")

    while True:
        print("\nMenú Principal:")
        print("1. Entrenar modelo")
        print("2. Predecir emoción")
        print("3. Salir")

        choice = input("Seleccione una opción: ")

        if choice == "1":
            data_path = input("Ruta del dataset (presione Enter para usar 'archive'): ") or "archive"
            trainer = EmotionTrainer(data_path)

            print("\nMétodos de preprocesamiento disponibles:")
            for i, method in enumerate(trainer.preprocessing_methods.keys(), 1):
                print(f"{i}. {method}")
            prep_choice = input("Seleccione método de preprocesamiento: ")

            methods = list(trainer.preprocessing_methods.keys())
            try:
                prep_index = int(prep_choice) - 1
                if 0 <= prep_index < len(methods):
                    method = methods[prep_index]
                    trainer.train(preprocessing=method, model_name="ModeloSVC_0.0.1")
                    print_model_info({
                        'emotions': trainer.emotions,
                        'accuracy': trainer.accuracy,
                        'prior_probabilities': trainer.prior_probabilities,
                        'preprocessing_method': method
                    })
                else:
                    print("Opción no válida, usando normalización por defecto")
                    trainer.train()
            except ValueError:
                print("Entrada inválida, usando normalización por defecto")
                trainer.train()

        elif choice == "2":
            model_path = input(
                "Ruta del modelo (presione Enter para usar 'model/emotion_classifier.joblib'): ") or "model/emotion_classifier.joblib"

            try:
                predictor = EmotionPredictor(model_path)
                model_info = predictor.get_model_info()
                print_model_info(model_info)

                print("\nOpciones de predicción:")
                print("1. Usar imagen de archivo")
                print("2. Usar cámara web")
                pred_choice = input("Seleccione una opción: ")

                if pred_choice == "1":
                    image_path = input("Ingrese la ruta de la imagen: ")
                    if not os.path.exists(image_path):
                        print("Error: La imagen no existe")
                        continue

                    result = predictor.predict_emotion(image_path)
                    print("\nResultado de la predicción:")
                    print(f"Emoción: {result['emotion']}")
                    print(f"Confianza: {result['confidence']:.2f}")
                    print("Probabilidades completas:")
                    for emotion, prob in result['probabilities'].items():
                        print(f"  {emotion}: {prob:.2f}")

                elif pred_choice == "2":
                    print("Presione 'q' para salir de la cámara")
                    cap = cv2.VideoCapture(0)

                    while True:
                        ret, frame = cap.read()
                        if not ret:
                            break

                        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                        result = predictor.predict_emotion(gray)

                        cv2.putText(frame, f"Emotion: {result['emotion']}", (10, 30),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                        cv2.putText(frame, f"Confidence: {result['confidence']:.2f}", (10, 70),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                        cv2.imshow('Emotion Recognition', frame)

                        if cv2.waitKey(1) & 0xFF == ord('q'):
                            break

                    cap.release()
                    cv2.destroyAllWindows()
                else:
                    print("Opción no válida")

            except FileNotFoundError:
                print("Error: No se encontró el modelo especificado")
            except Exception as e:
                print(f"Error: {str(e)}")

        elif choice == "3":
            print("Saliendo...")
            break
        else:
            print("Opción no válida")


if __name__ == "__main__":
    main()