import cv2
import numpy as np
import joblib


class EmotionPredictor:
    def __init__(self, model_path):
        # Cargar el modelo y metadatos
        loaded = joblib.load(model_path)
        self.model = loaded['model']
        self.emotions = loaded['emotions']
        self.prior_probabilities = loaded.get('prior_probabilities', None)
        self.accuracy = loaded.get('accuracy', None)
        self.preprocessing_type = loaded.get('preprocessing', 'normalize')

        # Configurar el método de preprocesamiento
        self.preprocessor = self._get_preprocessor(self.preprocessing_type)

    def _get_preprocessor(self, preprocessing_type):
        """Devuelve la función de preprocesamiento adecuada"""
        preprocessors = {
            'normalize': self._normalize,
            'hist_equalization': self._histogram_equalization,
            'edge_enhance': self._edge_enhancement,
            'full_preprocess': self._full_preprocessing
        }
        return preprocessors.get(preprocessing_type, self._normalize)

    def _normalize(self, image):
        """Normalización básica de píxeles"""
        return image / 255.0

    def _histogram_equalization(self, image):
        """Ecualización del histograma"""
        if len(image.shape) == 2:
            return cv2.equalizeHist(image.astype(np.uint8)).astype(np.float32) / 255.0
        return image

    def _edge_enhancement(self, image):
        """Realce de bordes"""
        if len(image.shape) == 2:
            image = (image * 255).astype(np.uint8)
            laplacian = cv2.Laplacian(image, cv2.CV_64F)
            enhanced = cv2.addWeighted(image, 1.5, laplacian, -0.5, 0)
            return enhanced.astype(np.float32) / 255.0
        return image

    def _full_preprocessing(self, image):
        """Preprocesamiento completo"""
        if len(image.shape) == 2:
            img = (image * 255).astype(np.uint8) if image.max() <= 1 else image.astype(np.uint8)
            img = cv2.equalizeHist(img)
            img = cv2.GaussianBlur(img, (3, 3), 0)

            # Convertir a float32 para operaciones
            img_float = img.astype(np.float32)
            laplacian = cv2.Laplacian(img_float, cv2.CV_32F)

            # Asegurar que ambos arrays son float32
            enhanced = cv2.addWeighted(img_float, 1.5, laplacian.astype(np.float32), -0.5, 0)

            return enhanced / 255.0
        return image

    def preprocess_image(self, image, preprocessing=None):
        """Preprocesa una imagen para la predicción"""
        if isinstance(image, str):
            # Si es una ruta de archivo, cargar la imagen
            img = cv2.imread(image, cv2.IMREAD_GRAYSCALE)
        else:
            # Si ya es una imagen numpy array
            img = image

        img = cv2.resize(img, (48, 48))

        # Aplicar preprocesamiento
        if preprocessing is not None:
            preprocessor = self._get_preprocessor(preprocessing)
            processed_img = preprocessor(img)
        else:
            processed_img = self.preprocessor(img)

        return processed_img.flatten().reshape(1, -1)

    def predict_emotion(self, image, preprocessing=None):
        """Predice la emoción de una imagen con opción de preprocesamiento específico"""
        processed_img = self.preprocess_image(image, preprocessing)
        prediction = self.model.predict(processed_img)
        probabilities = self.model.predict_proba(processed_img)[0]

        return {
            'emotion': self.emotions[prediction[0]],
            'emotion_index': prediction[0],
            'probabilities': dict(zip(self.emotions, probabilities)),
            'confidence': probabilities.max(),
            'preprocessing_used': preprocessing if preprocessing is not None else self.preprocessing_type
        }

    def predict_multiple(self, images, preprocessing=None):
        """Predice emociones para múltiples imágenes"""
        return [self.predict_emotion(img, preprocessing) for img in images]

    def get_model_info(self):
        """Devuelve información del modelo cargado"""
        return {
            'emotions': self.emotions,
            'prior_probabilities': self.prior_probabilities,
            'accuracy': self.accuracy,
            'feature_count': self.model.n_features_in_ if hasattr(self.model, 'n_features_in_') else None,
            'preprocessing_method': self.preprocessing_type
        }