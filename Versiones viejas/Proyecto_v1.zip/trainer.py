import os
import cv2
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import joblib
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from joblib import Parallel, delayed


class EmotionTrainer:
    def __init__(self, data_path="archive"):
        self.data_path = data_path
        self.emotions = ["angry", "disgust", "fear", "happy", "neutral", "sad", "surprise"]
        self.model = make_pipeline(
            StandardScaler(),
            SVC(kernel='rbf', C=1, gamma=0.05, probability=True, max_iter=10000, random_state=42, verbose=True)
        )
        self.prior_probabilities = None
        self.accuracy = None
        self.confusion_matrix = None
        self.preprocessing_methods = {
            'normalize': self._normalize,
            'hist_equalization': self._histogram_equalization,
            'edge_enhance': self._edge_enhancement,
            'full_preprocess': self._full_preprocessing
        }


    def _normalize(self, image):
        """Normalización básica de píxeles"""
        return image / 255.0

    def _histogram_equalization(self, image):
        """Ecualización del histograma para mejorar contraste"""
        if len(image.shape) == 2:  # Imagen en escala de grises
            return cv2.equalizeHist(image.astype(np.uint8)).astype(np.float32) / 255.0
        else:
            # Para imágenes en color (aunque nuestro caso usa escala de grises)
            img_yuv = cv2.cvtColor(image, cv2.COLOR_BGR2YUV)
            img_yuv[:, :, 0] = cv2.equalizeHist(img_yuv[:, :, 0])
            return cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)

    def _edge_enhancement(self, image):
        """Realce de bordes usando filtro Laplaciano"""
        if len(image.shape) == 2:
            image = (image * 255).astype(np.uint8)
            laplacian = cv2.Laplacian(image, cv2.CV_64F)
            enhanced = cv2.addWeighted(image, 1.5, laplacian, -0.5, 0)
            return enhanced.astype(np.float32) / 255.0
        return image

    def _full_preprocessing(self, image):
        """Combinación de varias técnicas de preprocesamiento"""
        if len(image.shape) == 2:
            # Convertir a uint8 para las operaciones de OpenCV
            img = (image * 255).astype(np.uint8) if image.max() <= 1 else image.astype(np.uint8)

            # 1. Ecualización del histograma
            img = cv2.equalizeHist(img)

            # 2. Filtrado Gaussiano para reducir ruido
            img = cv2.GaussianBlur(img, (3, 3), 0)

            # 3. Realce de bordes - Asegurando tipos compatibles
            img_float = img.astype(np.float32)  # Convertir a float32 para el Laplaciano
            laplacian = cv2.Laplacian(img_float, cv2.CV_32F)

            # Convertir todo a float32 para addWeighted
            img_float = img_float.astype(np.float32)
            laplacian = laplacian.astype(np.float32)

            # Aplicar el realce de bordes
            enhanced = cv2.addWeighted(img_float, 1.5, laplacian, -0.5, 0)

            # Normalizar y devolver
            return enhanced / 255.0
        return image

    def _process_image(self, img_path, preprocess_func):
        """Procesa una imagen individual para carga paralela"""
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (48, 48))
        img = preprocess_func(img)
        return img.flatten()

    def load_images(self, subset="train", preprocessing='normalize'):
        """Carga imágenes en paralelo con barra de progreso"""
        images = []
        labels = []
        subset_path = os.path.join(self.data_path, subset)
        preprocess_func = self.preprocessing_methods.get(preprocessing, self._normalize)

        # Prepara lista de todas las rutas de imágenes y etiquetas
        img_paths = []
        img_labels = []
        for i, emotion in enumerate(self.emotions):
            emotion_path = os.path.join(subset_path, emotion)
            for img_file in os.listdir(emotion_path):
                img_paths.append(os.path.join(emotion_path, img_file))
                img_labels.append(i)

        # Procesamiento paralelo con barra de progreso
        print(f"Cargando imágenes con preprocesamiento '{preprocessing}'...")
        images = Parallel(n_jobs=-1)(
            delayed(self._process_image)(img_path, preprocess_func)
            for img_path in tqdm(img_paths, desc="Procesando imágenes")
        )

        return np.array(images), np.array(img_labels)

    def plot_confusion_matrix(self):
        """Visualiza la matriz de confusión"""
        plt.figure(figsize=(10, 8))
        sns.heatmap(self.confusion_matrix, annot=True, fmt='d', cmap='Blues',
                    xticklabels=self.emotions, yticklabels=self.emotions)
        plt.title('Matriz de Confusión')
        plt.ylabel('Etiqueta Real')
        plt.xlabel('Etiqueta Predicha')
        plt.show()

    def train(self, save_model=True, model_name="emotion_classifier.joblib", preprocessing='normalize'):
        """Entrena el modelo con barra de progreso mejorada"""
        X, y = self.load_images("train", preprocessing=preprocessing)
        self.calculate_prior_probabilities(y)

        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=0.2, random_state=42)

        print("\nEntrenando modelo SVM (puede tomar tiempo)...")

        # Entrenamiento con barra de progreso aproximada
        with tqdm(total=100, desc="Progreso general") as pbar:
            self.model.fit(X_train, y_train)
            pbar.update(70)  # El entrenamiento representa ~70% del proceso
            print("\nEntrenamiento finalizado ...\n\nIniciando evaluacion...")
            # Evaluación
            val_pred = self.model.predict(X_val)
            self.accuracy = accuracy_score(y_val, val_pred)
            self.confusion_matrix = confusion_matrix(y_val, val_pred)
            pbar.update(20)

            if save_model:
                os.makedirs("model", exist_ok=True)
                model_path = os.path.join("model", model_name)
                joblib.dump({
                    'model': self.model,
                    'emotions': self.emotions,
                    'accuracy': self.accuracy,
                    'confusion_matrix': self.confusion_matrix,
                    'prior_probabilities': self.prior_probabilities,
                    'preprocessing': preprocessing
                }, model_path)
                pbar.update(10)
                print(f"\nModelo guardado en {model_path}")

        print("\nMétricas de Evaluación:")
        print(f"Precisión (Accuracy): {self.accuracy:.2f}")
        print("\nReporte de Clasificación:")
        print(classification_report(y_val, val_pred, target_names=self.emotions))

        self.plot_confusion_matrix()
        return self.model

    def calculate_prior_probabilities(self, y):
        """Calcula las probabilidades a priori de cada clase"""
        unique, counts = np.unique(y, return_counts=True)
        self.prior_probabilities = dict(zip(self.emotions, counts / len(y)))
        return self.prior_probabilities

    def get_model_info(self):
        """Devuelve información importante del modelo"""
        return {
            'emotions': self.emotions,
            'prior_probabilities': self.prior_probabilities,
            'accuracy': self.accuracy,
            'feature_count': self.model.n_features_in_ if hasattr(self.model, 'n_features_in_') else None,
            'preprocessing_methods': list(self.preprocessing_methods.keys())
        }